# DocDraw Spec Release Bundle (v1.0)

This bundle is a snapshot of the DocDraw v1.0 standard and its executable conformance materials.

## Contents
- `docs/` (spec pages + navigation)
- `examples/golden-manifest.json` (examples source of truth)
- `examples/source/` (fixtures)
- `assets/examples/` (normalized goldens today; PDF goldens later)
- `CONTRIBUTING.md`

## Verification
Use the accompanying `.sha256` file to verify integrity.


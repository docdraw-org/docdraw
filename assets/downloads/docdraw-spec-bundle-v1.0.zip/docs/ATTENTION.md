# Attention Needed (to finalize DocDraw v1)

This file tracks **decisions that should be made explicitly** so the spec + golden outputs are stable.

## Naming
- Canonical name for the format: **DocDraw v1**

## PDF defaults (should be locked)
- Paper: **Letter only** vs **Letter + A4** as first-class setting
- Default font family to embed: **Source Serif 4** vs **Inter** (or other)
- Ordered list marker format:
  - simplest: numeric `1.` at every level, tracked per level
  - alternative: `1.` / `a.` / `i.` etc
- Bullet glyphs:
  - Level 1: `•` (likely)
  - Level 2: `◦` (likely)
  - Level 3+: choose `▪` vs `–` and lock it

## Inline styling policy
- Confirm whether DocDraw v1 supports inline:
  - **none** (plain text only)
  - **bold/italic only**
  - (anything more should probably wait)

## Scope confirmation (v1)
- README says “no tables/images initially” — confirm this is still true for v1
- Confirm whether blockquotes (`q:`) and code blocks (`code{}`) are in v1 MVP or v1.1



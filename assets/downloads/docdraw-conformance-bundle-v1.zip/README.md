# DocDraw Conformance Bundle (v1)

This bundle contains the canonical conformance fixtures used to verify implementations of:

- DocDraw v1 (language)
- DMP-1 (Markdown profile)
- DD-PDF-1 (renderer profile; PDFs may be absent until the reference compiler exists)

## Contents
- \`examples/golden-manifest.json\` (source of truth)
- \`examples/source/\` (fixtures)
- \`assets/examples/\` (normalized goldens today; PDF goldens later)
- \`CONTRIBUTING.md\` (workflow and rules)

## Quick usage (repo layout)
If you unzip this into the DocDraw.org repo root:

```bash
make examples-update
make examples-check
```

